//
//  AppCoordinator.swift
//  Trabalho-Desenvolvimento-IOS1
//
//  Created by Breno Ramos on 10/09/23.
//

import Foundation
import UIKit

final class AppCoordinator: Coordinator {

    private let window: UIWindow?
    private let navigationController: UINavigationController

    var childCoordinators: [Coordinator] = []

    init(
        window: UIWindow?,
        navigationController: UINavigationController
    ) {
        self.window = window
        self.navigationController = navigationController
    }

    func start() {
        guard let window = window else { return }
        window.rootViewController = navigationController
        window.makeKeyAndVisible()
        createListScene()
    }

    private func createListScene() {
        let listCoordinator = ListCoordinator(navigationController: self.navigationController)
        listCoordinator.delegate = self
        childCoordinators.append(listCoordinator)
        listCoordinator.start()
    }
}

extension AppCoordinator: ListCoordinatorDelegate {
    func didFinishListCoordinator(_ coordinator: Coordinator) {
        childCoordinators = childCoordinators.filter { $0 !== coordinator }
    }
}
