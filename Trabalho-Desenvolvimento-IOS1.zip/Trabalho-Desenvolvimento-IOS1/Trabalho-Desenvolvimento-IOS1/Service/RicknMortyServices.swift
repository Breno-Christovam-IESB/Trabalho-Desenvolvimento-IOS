//
//  RicknMortyService.swift
//  Trabalho-Desenvolvimento-IOS1
//
//  Created by Breno Ramos on 10/09/23.
//

import Foundation

enum RicknMortyServiceError: Error {
    case invalidAPIURL
    case couldNotFetchCharacterList
    case invalidJSONFormat
}

class RicknMortyServices {
    private let baseURL = "https://rickandmortyapi.com"

    func fetchCharacterList(page: Int = 1) async throws -> [RicknMortyCharacters] {
        let endpoint = "/api/character/?page=\(page)"
        guard let url = URL(string: baseURL + endpoint) else {
            throw RicknMortyServiceError.invalidAPIURL
        }

        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            let response = try JSONDecoder().decode(RicknMortyResponses.self, from: data)
            return response.results
        } catch {
            throw RicknMortyServiceError.couldNotFetchCharacterList
        }
    }
}
