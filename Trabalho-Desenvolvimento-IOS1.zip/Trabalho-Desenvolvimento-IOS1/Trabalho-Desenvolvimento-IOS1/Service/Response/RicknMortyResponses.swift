//
//  RicknMortyResponses.swift
//  Trabalho-Desenvolvimento-IOS1
//
//  Created by Breno Ramos on 10/09/23.
//

import Foundation

struct RicknMortyResponses: Decodable {
    let results: [RicknMortyCharacters]

    enum CodingKeys: CodingKey {
        case results
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.results = try container.decode([RicknMortyCharacters].self, forKey: .results)
    }
}
