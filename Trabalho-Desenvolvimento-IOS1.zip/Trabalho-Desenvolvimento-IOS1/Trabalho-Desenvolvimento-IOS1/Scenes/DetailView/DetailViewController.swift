//
//  DetailViewController.swift
//  Trabalho-Desenvolvimento-IOS1
//
//  Created by Breno Ramos on 10/09/23.
//


import UIKit

final class DetailViewController: UIViewController {

    private let detailLabel = UILabel()


    init(text: String) {
        super.init(nibName: nil, bundle: nil)
        configureView()

        detailLabel.text = text
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

private extension DetailViewController {
    func configureView() {
        self.view.backgroundColor = .red
        configureLabel()
    }

    func configureLabel() {
        self.view.addSubview(detailLabel)
        detailLabel.textAlignment = .center
        detailLabel.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            detailLabel.topAnchor.constraint(equalTo: self.view.layoutMarginsGuide.topAnchor, constant: 50),
            detailLabel.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -20),
            detailLabel.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 20),
            detailLabel.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
}
