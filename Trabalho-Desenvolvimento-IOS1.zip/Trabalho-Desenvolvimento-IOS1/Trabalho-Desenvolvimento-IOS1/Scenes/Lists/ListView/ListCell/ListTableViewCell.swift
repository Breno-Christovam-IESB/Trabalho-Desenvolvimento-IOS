//
//  ListTableViewCell.swift
//  Trabalho-Desenvolvimento-IOS1
//
//  Created by Breno Ramos on 10/09/23.
//


import UIKit

final class ListTableViewCell: UITableViewCell {
    static var reuseIdentifier: String = "ListTableViewCell"

    private let profileImageView: UIImageView = UIImageView()
    private let nameLabel: UILabel = UILabel()
    private let speciesLabel: UILabel = UILabel()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        configureImageView()
        configureLabels()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func prepareForReuse() {
        super.prepareForReuse()
        profileImageView.image = nil
        nameLabel.text = nil
        speciesLabel.text = nil
    }

    func configure(viewModel: ListCellModel) {
        profileImageView.load(url: viewModel.url)
        nameLabel.text = viewModel.title
        speciesLabel.text = viewModel.subtitle
    }
}

private extension ListTableViewCell {
    func configureImageView() {
        contentView.addSubview(profileImageView)

        profileImageView.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            profileImageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            profileImageView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            profileImageView.heightAnchor.constraint(equalToConstant: 50),
            profileImageView.widthAnchor.constraint(equalToConstant: 50),
        ])
    }

    func configureLabels() {
        contentView.addSubview(nameLabel)
        contentView.addSubview(speciesLabel)

        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        speciesLabel.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            nameLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 20),
            nameLabel.leadingAnchor.constraint(equalTo: profileImageView.trailingAnchor, constant: 20),
            nameLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),

            speciesLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 20),
            speciesLabel.leadingAnchor.constraint(equalTo: profileImageView.trailingAnchor, constant: 20),
            speciesLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            speciesLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -20),
        ])
    }
}

fileprivate extension UIImageView {
    func load(url: URL?) {
        guard let url = url else { return }

        DispatchQueue.global().async { [weak self] in
            if let data = try? Data(contentsOf: url), let image = UIImage(data: data) {
                DispatchQueue.main.async {
                    self?.image = image
                }
            }
        }
    }
}
