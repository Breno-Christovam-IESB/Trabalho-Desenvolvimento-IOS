//
//  ListViewController.swift
//  Trabalho-Desenvolvimento-IOS1
//
//  Created by Breno Ramos on 10/09/23.
//

import UIKit

final class ListViewController: UIViewController {

    private let tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .grouped)
        return tableView
    }()

    var viewModel: ListViewModelProtocol

    init(viewModel: ListViewModelProtocol) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        configureView()
        bindingViewModel()

        viewModel.requestCharacters()
    }

    private func bindingViewModel() {
        viewModel.listDidChange = { viewModel in
//            self.title = viewModel.title
            self.viewModel = viewModel
            DispatchQueue.main.async { [weak self] in
                self?.tableView.reloadData()
            }
        }

        viewModel.textDidChange = { text in
            print(text)
        }
    }
}

private extension ListViewController {
    func configureView() {
        configureTableView()
        configureTableViewLayout()
    }

    func configureTableView() {
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(
            ListTableViewCell.self,
            forCellReuseIdentifier: ListTableViewCell.reuseIdentifier
        )
        tableView.estimatedRowHeight = 55
        tableView.rowHeight = UITableView.automaticDimension
    }

    func configureTableViewLayout() {
        view.addSubview(tableView)

        tableView.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }
}

extension ListViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.cells.count
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        viewModel.didTapListItem(at: indexPath.row)
        tableView.deselectRow(at: indexPath, animated: true)
    }
}

extension ListViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: ListTableViewCell.reuseIdentifier, for: indexPath) as? ListTableViewCell else {
            return UITableViewCell()
        }

        let cellViewModel = viewModel.cells[indexPath.row]
        cell.configure(viewModel: cellViewModel)
        return cell
    }
}
