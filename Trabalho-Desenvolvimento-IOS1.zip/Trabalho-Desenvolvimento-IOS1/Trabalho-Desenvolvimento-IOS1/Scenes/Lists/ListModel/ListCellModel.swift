//
//  ListCellModel.swift
//  Trabalho-Desenvolvimento-IOS1
//
//  Created by Breno Ramos on 10/09/23.
//

import Foundation

struct ListCellModel {
    let title: String
    let subtitle: String
    let url: URL?
}
