//
//  ListViewModel.swift
//  Trabalho-Desenvolvimento-IOS1
//
//  Created by Breno Ramos on 10/09/23.
//

import Foundation

protocol ListViewModelCoordinatorDelegate: AnyObject {
    func didTapListItem(with title: String)
}

final class ListViewModel: ListViewModelProtocol {

    var listDidChange: ((ListViewModelProtocol) -> ())?

    var textDidChange: ((String) -> ())?

    weak var coordinatorDelegate: ListViewModelCoordinatorDelegate?

    var cells: [ListCellModel] = [] {
        didSet {
            self.listDidChange?(self)
        }
    }

    private let service: RicknMortyServices

    init(
        service: RicknMortyServices
    ) {
        self.service = service
    }

    func requestCharacters() {
        Task { [weak self] in
            guard let self = self else { return }
            do {
                let characterList = try await service.fetchCharacterList(page: 4)

                self.cells = characterList.map {
                    ListCellModel(
                        title: $0.name,
                        subtitle: $0.species,
                        url: $0.imageURL
                    )
                }
            } catch let error {
                if let error = error as? RicknMortyServiceError {
                }
            }
        }
    }

    func didTapListItem(at index: Int) {
        let subtitle = cells[index].subtitle
        coordinatorDelegate?.didTapListItem(with: subtitle)
    }
}
