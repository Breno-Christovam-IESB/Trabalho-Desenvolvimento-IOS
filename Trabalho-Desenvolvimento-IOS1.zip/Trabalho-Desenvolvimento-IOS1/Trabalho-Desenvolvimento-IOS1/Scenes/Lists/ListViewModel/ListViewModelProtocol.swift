//
//  ListViewModelProtocol.swift
//  Trabalho-Desenvolvimento-IOS1
//
//  Created by Breno Ramos on 10/09/23.
//

import Foundation

protocol ListViewModelProtocol {
    // Observer
    var listDidChange: ((ListViewModelProtocol) -> ())? { get set }
    var textDidChange: ((String) -> ())? { get set }

    var cells: [ListCellModel] { get }
    func requestCharacters()
    func didTapListItem(at index: Int)
}
