//
//  ListCoordinator.swift
//  Trabalho-Desenvolvimento-IOS1
//
//  Created by Breno Ramos on 10/09/23.
//


import UIKit

protocol ListCoordinatorDelegate: AnyObject {
    func didFinishListCoordinator(_ coordinator: Coordinator)
}

final class ListCoordinator: Coordinator {
    private let navigationController: UINavigationController
    public weak var delegate: ListCoordinatorDelegate?

    var childCoordinators: [Coordinator] = []

    init(
        navigationController: UINavigationController
    ) {
        self.navigationController = navigationController
    }

    func start() {
        let viewModel = ListViewModel(
            service: RicknMortyServices()
        )
        viewModel.coordinatorDelegate = self
        let viewController = ListViewController(viewModel: viewModel)
        navigationController.viewControllers.append(viewController)
    }
}

extension ListCoordinator: ListViewModelCoordinatorDelegate {
    func didTapListItem(with title: String) {
        let viewController = DetailViewController(
            text: title
        )
        navigationController.pushViewController(viewController, animated: true)
    }
}
